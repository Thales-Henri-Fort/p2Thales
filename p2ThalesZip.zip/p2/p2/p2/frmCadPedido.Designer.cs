﻿namespace p2
{
    partial class frmCadPedido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lblNomeCliente = new Label();
            label3 = new Label();
            label4 = new Label();
            lblTotalPedido = new Label();
            label6 = new Label();
            btnBuscarCliente = new Button();
            btnGravar = new Button();
            btnExcluir = new Button();
            btnAdicionar = new Button();
            txtCpfCliente = new TextBox();
            cmbProduto = new ComboBox();
            numQuantidade = new NumericUpDown();
            dgvItensPedido = new DataGridView();
            btnVoltar = new Button();
            ((System.ComponentModel.ISupportInitialize)numQuantidade).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvItensPedido).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 31);
            label1.Name = "label1";
            label1.Size = new Size(28, 15);
            label1.TabIndex = 0;
            label1.Text = "CPF";
            // 
            // lblNomeCliente
            // 
            lblNomeCliente.AutoSize = true;
            lblNomeCliente.Location = new Point(235, 31);
            lblNomeCliente.Name = "lblNomeCliente";
            lblNomeCliente.Size = new Size(40, 15);
            lblNomeCliente.TabIndex = 1;
            lblNomeCliente.Text = "Nome";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 69);
            label3.Name = "label3";
            label3.Size = new Size(50, 15);
            label3.TabIndex = 2;
            label3.Text = "Produto";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(195, 69);
            label4.Name = "label4";
            label4.Size = new Size(69, 15);
            label4.TabIndex = 3;
            label4.Text = "Quantidade";
            // 
            // lblTotalPedido
            // 
            lblTotalPedido.AutoSize = true;
            lblTotalPedido.Location = new Point(24, 233);
            lblTotalPedido.Name = "lblTotalPedido";
            lblTotalPedido.Size = new Size(32, 15);
            lblTotalPedido.TabIndex = 4;
            lblTotalPedido.Text = "Total";
            lblTotalPedido.Click += lblTotalPedido_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(81, 233);
            label6.Name = "label6";
            label6.Size = new Size(20, 15);
            label6.TabIndex = 5;
            label6.Text = "R$";
            // 
            // btnBuscarCliente
            // 
            btnBuscarCliente.Location = new Point(158, 27);
            btnBuscarCliente.Name = "btnBuscarCliente";
            btnBuscarCliente.Size = new Size(75, 23);
            btnBuscarCliente.TabIndex = 6;
            btnBuscarCliente.Text = "Buscar";
            btnBuscarCliente.UseVisualStyleBackColor = true;
            btnBuscarCliente.Click += btnBuscarCliente_Click;
            // 
            // btnGravar
            // 
            btnGravar.Location = new Point(29, 296);
            btnGravar.Name = "btnGravar";
            btnGravar.Size = new Size(99, 23);
            btnGravar.TabIndex = 7;
            btnGravar.Text = "Gravar Pedido";
            btnGravar.UseVisualStyleBackColor = true;
            btnGravar.Click += btnGravar_Click;
            // 
            // btnExcluir
            // 
            btnExcluir.Location = new Point(29, 325);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(99, 23);
            btnExcluir.TabIndex = 8;
            btnExcluir.Text = "Excluir Pedido";
            btnExcluir.UseVisualStyleBackColor = true;
            btnExcluir.Click += btnExcluir_Click;
            // 
            // btnAdicionar
            // 
            btnAdicionar.Location = new Point(340, 65);
            btnAdicionar.Name = "btnAdicionar";
            btnAdicionar.Size = new Size(75, 23);
            btnAdicionar.TabIndex = 9;
            btnAdicionar.Text = "Adicionar";
            btnAdicionar.UseVisualStyleBackColor = true;
            btnAdicionar.Click += btnAdicionar_Click;
            // 
            // txtCpfCliente
            // 
            txtCpfCliente.Location = new Point(52, 27);
            txtCpfCliente.Name = "txtCpfCliente";
            txtCpfCliente.Size = new Size(100, 23);
            txtCpfCliente.TabIndex = 10;
            // 
            // cmbProduto
            // 
            cmbProduto.FormattingEnabled = true;
            cmbProduto.Location = new Point(68, 64);
            cmbProduto.Name = "cmbProduto";
            cmbProduto.Size = new Size(121, 23);
            cmbProduto.TabIndex = 11;
            cmbProduto.SelectedIndexChanged += cmbProduto_SelectedIndexChanged;
            // 
            // numQuantidade
            // 
            numQuantidade.Location = new Point(267, 65);
            numQuantidade.Name = "numQuantidade";
            numQuantidade.Size = new Size(56, 23);
            numQuantidade.TabIndex = 12;
            // 
            // dgvItensPedido
            // 
            dgvItensPedido.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvItensPedido.Location = new Point(24, 103);
            dgvItensPedido.Name = "dgvItensPedido";
            dgvItensPedido.Size = new Size(404, 107);
            dgvItensPedido.TabIndex = 13;
            // 
            // btnVoltar
            // 
            btnVoltar.Location = new Point(358, 325);
            btnVoltar.Name = "btnVoltar";
            btnVoltar.Size = new Size(75, 23);
            btnVoltar.TabIndex = 14;
            btnVoltar.Text = "Voltar";
            btnVoltar.UseVisualStyleBackColor = true;
            btnVoltar.Click += btnVoltar_Click;
            // 
            // frmCadPedido
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(463, 450);
            Controls.Add(btnVoltar);
            Controls.Add(dgvItensPedido);
            Controls.Add(numQuantidade);
            Controls.Add(cmbProduto);
            Controls.Add(txtCpfCliente);
            Controls.Add(btnAdicionar);
            Controls.Add(btnExcluir);
            Controls.Add(btnGravar);
            Controls.Add(btnBuscarCliente);
            Controls.Add(label6);
            Controls.Add(lblTotalPedido);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(lblNomeCliente);
            Controls.Add(label1);
            Name = "frmCadPedido";
            Text = "frmCadPedido";
            ((System.ComponentModel.ISupportInitialize)numQuantidade).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvItensPedido).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label lblNomeCliente;
        private Label label3;
        private Label label4;
        private Label lblTotalPedido;
        private Label label6;
        private Button btnBuscarCliente;
        private Button btnGravar;
        private Button btnExcluir;
        private Button btnAdicionar;
        private TextBox txtCpfCliente;
        private ComboBox cmbProduto;
        private NumericUpDown numQuantidade;
        private DataGridView dgvItensPedido;
        private Button btnVoltar;
    }
}