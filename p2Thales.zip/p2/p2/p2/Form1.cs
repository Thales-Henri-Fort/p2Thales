namespace p2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text.Trim();
            string senha = txtSenha.Text;

            bool credenciaisValidas = false;

            // Verifica se � o admin
            if (usuario.Equals("ADMIN", StringComparison.OrdinalIgnoreCase) && senha == "123")
            {
                credenciaisValidas = true;
            }
            else
            {
                // Verifica as credenciais no CSV
                string caminhoArquivo = "Usu.csv"; // certifica que o arquivo est� no diret�rio correto

                if (File.Exists(caminhoArquivo))
                {
                    var linhas = File.ReadAllLines(caminhoArquivo);

                    foreach (string linha in linhas)
                    {
                        string[] partes = linha.Split(',');
                        if (partes.Length == 2)
                        {
                            string usuarioArquivo = partes[0].Trim();
                            string senhaArquivo = partes[1].Trim();

                            if (usuario.Equals(usuarioArquivo, StringComparison.OrdinalIgnoreCase) && senha == senhaArquivo)
                            {
                                credenciaisValidas = true;
                                break;
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Arquivo de usu�rios n�o encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            if (credenciaisValidas)
            {
                MessageBox.Show("Login realizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Abrir formul�rio principal
                frmPrincipal princ = new frmPrincipal();
                princ.Show();
                this.Hide(); // esconde o formul�rio de login
            }
            else
            {
                MessageBox.Show("Usu�rio ou senha inv�lidos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
